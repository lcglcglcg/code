

#ifndef	__CONTROL_DEIVERS_H__
#define	__CONTROL_DEIVERS_H__

#ifdef __cplusplus
extern "C" {
#endif

    extern void get_deivers_mac_addr(char *mac_addr);
    extern void get_deivers_cpuid(char *cpu_id);
    extern void get_deivers_disk(char *disk_id);
    extern int get_deivers_licence(const char *path, char *licence);
extern char *get_deivers_cpuinfo(void);

#ifdef __cplusplus
}
#endif
#endif


