
#ifndef	__CONTROL_CENTER_H__
#define	__CONTROL_CENTER_H__

#include <jni.h>
#include <stdio.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

    extern int jni_printf(const char *str);
    extern int com_sinotawa_framework_util_errorenum_init(JNIEnv *env);
    extern int com_sinotawa_framework_event_eventmanager_starteventmanager(JNIEnv *env);
    extern int com_sinotawa_framework_event_eventthreadpool_init(JNIEnv *env);
    extern int com_sinotawa_common_context_configcontext_init(JNIEnv *env);
    extern int com_sinotawa_message_framework_config_messagecontext_initconnections(JNIEnv *env);
    extern int com_sinotawa_jndi_common_memercontext_init(JNIEnv *env);
    extern int com_sinotawa_socket_jms_socketjmscontext_init(JNIEnv *env);

#ifdef __cplusplus
}
#endif
#endif


