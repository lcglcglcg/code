

#ifndef	__CONTROL_NETWORK_H__
#define	__CONTROL_NETWORK_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifdef	WIN32
#include <windows.h>
#else
#include <fcntl.h>
#include <errno.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#define	SOCKET int
#define	closesocket(sockfd) close(sockfd)
#endif

    extern SOCKET network_connect(const char *host, int port);
    extern int control_packet_key_check(const char *licence_path);

#ifdef __cplusplus
}
#endif
#endif


